# Canada Automotive Recalls API

This package is under development and currently used to interact with the canadian governments automotive database. 

## How to use

```Python
pip install canada_recalls
```